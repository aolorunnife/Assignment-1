clearvars; clearvars -GLOBAL 
close all
set(0,'DefaultFigureWindowStyle','docked')  % 'docked' 'normal'

%%electron modeling 

%solve for Vth
mo= 9.1093837015E-31;
mn = 0.26*mo;
%may need to an array to do this
l= 200E-9;  %come back into the other side
h= 100E-9;  %bounce back
a= l*h;
%%% ask TA
T= 300;
k= 1.38064852E-23;  %for thermal velocity
Tmn= 0.2E-12;  %mean free path 

%%2 OR 3???
Vth = sqrt((2*k*T)/(mn))

%mean free path
mfp = Vth*Tmn 

X = rand*l;  %random number between 0 and1 multiplied by limits of silicon
Y = rand*h;

Vx = Vth*rand  %x component
Vy = Vth*rand   %y component
%solve for Vy using magV equation %Vth*rand   %y component
magV = sqrt(Vx^2 + Vy^2);

dt = h/Vth/100  %should be 1/100 of the region size 

%%boundary conditions

numit=50;

for i=1:numit  %going from 1 iteraton to 5 
   figPlot = figure(1);
   hold on
   plot (X,Y,'o')
   axis([0 l 0 h])
   X= X + dt*Vx;
   Y= Y + dt*Vy;

  
    

    pause(.001)
end
hold off


