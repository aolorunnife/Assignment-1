figure(2)

% plot([0,1],[0,1])

Xp = 0;
Yp = 0;

X = 1;
Y = 1;

plot([Xp,X],[Yp,Y])